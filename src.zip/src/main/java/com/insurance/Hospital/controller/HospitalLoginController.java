package com.insurance.Hospital.controller;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.insurance.Hospital.contracts.LoginRepositoryInterface;
import com.insurance.Hospital.contracts.LoginServiceInterface;
import com.insurance.Hospital.models.LoginClass;
import com.insurance.Hospital.models.OTPclass;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

// Login Controller
@Controller
@RequestMapping(value = "/hospital")
public class HospitalLoginController {

	private final Logger logger;

	LoginServiceInterface loginServiceInterface;
	LoginRepositoryInterface loginRepositoryInterface;

	private HttpSession httpSession;

	@Autowired
	public HospitalLoginController(LoginServiceInterface lrep, Logger hospitalLoginControllerLogger,
			LoginRepositoryInterface ll, HttpSession httpSession) {
		this.loginServiceInterface = lrep;
		this.loginRepositoryInterface = ll;
		this.httpSession = httpSession;
		this.logger = hospitalLoginControllerLogger;
	}

	// Initially login page
	@GetMapping("")
	public String login(Model model) {
		logger.trace("Displaying login page.");
		model.addAttribute("login", new LoginClass());
		return "login";
	}

	// Forgot password page
	@GetMapping("/forgotpassword")
	public String forgotpassword(Model model) {
		logger.trace("Displaying forgot password page.");
		model.addAttribute("to", "");
		model.addAttribute("login", new OTPclass());
		model.addAttribute("enotp", "");
		model.addAttribute("otp", "");

		return "forgotpassword";
	}

	// Check credentials
	@PostMapping("/adminLogin")
	public String adminlogin(HttpServletRequest request, @ModelAttribute("login") LoginClass lc, Model model) {
		try {
			int check = loginServiceInterface.checkCredentials(lc);
			if (check == 1) {
				logger.info("Admin logged in successfully.");
				return "index";
			}

			model.addAttribute("user_name", "lc.getUser_name()");
			model.addAttribute("password", "lc.getPassword()");
			model.addAttribute("errorMessage", "incorrect credentials");
			logger.error("Incorrect credentials entered.");
			return "login";
		} catch (Exception ex) {
			logger.error("An error occurred while processing admin login: {}", ex.getMessage());
			model.addAttribute("errorMessage", "An error occurred while processing your request.");
			return "errorPage";
		}
	}

	// To send OTP to user
	@GetMapping("/email")
	@ResponseBody
	public String email(@RequestParam("to") String to_mail) {
		try {
			String email = to_mail;
			httpSession.setAttribute("email", email);
			// Storing generated OTP
			int OTP = loginRepositoryInterface.sendmail(to_mail);
			httpSession.setAttribute("OTP", OTP);
			logger.info("OTP sent successfully to email: {}", email);
			return "Email Sent Successfully";
		} catch (Exception ex) {
			logger.error("An error occurred while sending OTP: {}", ex.getMessage());
			return "Failed to send email";
		}
	}

	// To validate OTP
	@PostMapping(value = "/validateOTP")
	public ModelAndView validateOTP(@RequestParam("otp") String otp, Model model) {
		model.addAttribute("to", "");
		try {
			int OTP = Integer.parseInt(otp);
			ModelAndView mav = new ModelAndView();
			int originalOtp = (Integer) httpSession.getAttribute("OTP");
			String email = (String) httpSession.getAttribute("email");
			// Checking the OTP sent by the user. If true, return reset page, else stay
			// on the same page with an error message.
			if (originalOtp == OTP) {
				mav.setViewName("resetpassword");
				mav.addObject("email", email);
				logger.info("OTP validated successfully.");
				return mav;
			}
			mav.setViewName("forgotPassword");
			mav.addObject("msg", "Please Enter Valid OTP");
			mav.addObject("email", email);
			logger.error("Invalid OTP entered.");
			return mav;
		} catch (Exception ex) {
			logger.error("An error occurred while validating OTP: {}", ex.getMessage());
			ModelAndView mav = new ModelAndView();
			mav.setViewName("forgotPassword");
			mav.addObject("msg", "An error occurred while processing your request.");
			return mav;
		}
	}

	// To reset password
	@PostMapping("/reset")
	public String reset(Model model, @RequestParam("email") String email, @RequestParam("pwd") String pwd,
			@RequestParam("cnfpwd") String cnfpwd) {
		try {
			logger.trace("Resetting password for email: {}", email);
			int x = loginServiceInterface.resetpwd(email, pwd);
			if (x == 1) {
				model.addAttribute("message", "password changed");
				logger.info("Password changed successfully.");
			} else {
				model.addAttribute("message", "error while password changing");
				logger.error("Error occurred while changing password.");
			}
			model.addAttribute("login", new LoginClass());
			return "login";
		} catch (Exception ex) {
			logger.error("An error occurred while resetting password: {}", ex.getMessage());
			model.addAttribute("errorMessage", "An error occurred while processing your request.");
			return "errorPage";
		}
	}
}
