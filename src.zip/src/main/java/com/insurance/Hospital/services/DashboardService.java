package com.insurance.Hospital.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.Hospital.models.ClaimBills;
import com.insurance.Hospital.contracts.DashboardDaoInterface;
import com.insurance.Hospital.contracts.DashboardServiceInterface;
import com.insurance.Hospital.models.Claim;

@Service
public class DashboardService implements DashboardServiceInterface {

	@Autowired
	DashboardDaoInterface dashboardDaoInterface;

	@Override
	public List<ClaimBills> getRejectedLoans() {

		return dashboardDaoInterface.getRejectedLoans();
	}
	@Override
	public List<Claim> getAllApplicants() {

		return dashboardDaoInterface.getAllApplicants();
	}

	@Override
	public List<Claim> getClaimedAmount() {

		return dashboardDaoInterface.getClaimedAmount();
	}

	@Override
	public List<Claim> getTotalAmount() {

		return dashboardDaoInterface.getTotalAmount();
	}

	@Override
	public List<Claim> getActiveApplicants() {

		return dashboardDaoInterface.getActiveApplicants();
	}
}