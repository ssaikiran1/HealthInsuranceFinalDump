package com.insurance.Hospital.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.Hospital.contracts.LoginDaoInterface;
import com.insurance.Hospital.contracts.LoginServiceInterface;
import com.insurance.Hospital.models.LoginClass;

@Service
public class LoginService implements LoginServiceInterface{
	
	@Autowired
	LoginDaoInterface loginDaoInterface;
	
	@Override
	public int checkCredentials(LoginClass lc) {
		return loginDaoInterface.checkCredentials(lc);
	}
	@Override
	public int resetpwd(String email, String pwd) {
		return loginDaoInterface.resetpwd(email, pwd);
	}
}
