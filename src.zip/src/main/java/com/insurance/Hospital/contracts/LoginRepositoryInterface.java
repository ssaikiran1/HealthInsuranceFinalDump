package com.insurance.Hospital.contracts;

public interface LoginRepositoryInterface {
	
	int sendmail(String to_mail);
}
