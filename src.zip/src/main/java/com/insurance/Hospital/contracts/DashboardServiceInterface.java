package com.insurance.Hospital.contracts;

import java.util.List;
import com.insurance.Hospital.models.ClaimBills;
import com.insurance.Hospital.models.Claim;


public interface DashboardServiceInterface {
	
	List<ClaimBills> getRejectedLoans();

	List<Claim> getAllApplicants();

	List<Claim> getClaimedAmount();

	List<Claim> getTotalAmount();

	List<Claim> getActiveApplicants();
	
}
