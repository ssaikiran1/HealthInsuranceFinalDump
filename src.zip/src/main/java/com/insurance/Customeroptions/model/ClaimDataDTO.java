package com.insurance.Customeroptions.model;

import java.util.List;

public class ClaimDataDTO {
    private Claim claim;
    public Claim getClaim() {
		return claim;
	}
	public void setClaim(Claim claim) {
		this.claim = claim;
	}
	public List<ClaimBills> getClaimBill() {
		return claimBill;
	}
	public void setClaimBill(List<ClaimBills> claimBill) {
		this.claimBill = claimBill;
	}
	public List<Uploads> getUploads() {
		return uploads;
	}
	public void setUploads(List<Uploads> uploads) {
		this.uploads = uploads;
	}
	public List<ReUpload> getReuploads() {
		return reuploads;
	}
	public void setReuploads(List<ReUpload> reuploads) {
		this.reuploads = reuploads;
	}
	public int getClaimPolicyId() {
		return claimPolicyId;
	}
	public void setClaimPolicyId(int claimPolicyId) {
		this.claimPolicyId = claimPolicyId;
	}
	public List<String> getPatientNames() {
		return patientNames;
	}
	public void setPatientNames(List<String> patientNames) {
		this.patientNames = patientNames;
	}
	private List<ClaimBills> claimBill;
    private List<Uploads> uploads;
    private List<ReUpload> reuploads;
    private int claimPolicyId;
    private List<String> patientNames;

    // Getters and setters for all fields
    
    
    @Override
    public String toString() {
        return "ClaimDataDTO{" +
                "claim=" + claim +
                ", claimBill=" + claimBill +
                ", uploads=" + uploads +
                ", reuploads=" + reuploads +
                ", claimPolicyId=" + claimPolicyId +
                ", patientNames=" + patientNames +
                '}';
    }

}
