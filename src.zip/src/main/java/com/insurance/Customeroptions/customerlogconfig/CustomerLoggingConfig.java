package com.insurance.Customeroptions.customerlogconfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.insurance.Hospital.controller.DashboardController;
import com.insurance.Hospital.controller.HospitalClaimController;
import com.insurance.Hospital.controller.HospitalLoginController;

@Configuration
public class CustomerLoggingConfig {

	@Bean
	public Logger customerOptionsControllerLogger() {
		return LoggerFactory.getLogger(DashboardController.class);
	}

	@Bean
	public Logger insuranceClaimControllerLogger() {
		return LoggerFactory.getLogger(HospitalClaimController.class);
	}

	@Bean
	public Logger transactionControllerLogger() {
		return LoggerFactory.getLogger(HospitalLoginController.class);
	}

}
