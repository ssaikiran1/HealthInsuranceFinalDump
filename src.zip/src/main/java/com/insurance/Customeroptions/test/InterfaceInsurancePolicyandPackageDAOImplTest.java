package com.insurance.Customeroptions.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.insurance.Customeroptions.dao.InterfaceInsurancePolicyandPackageDAOImpl;
import com.insurance.Customeroptions.model.Faq;
import com.insurance.Customeroptions.model.FormData;
import com.insurance.Customeroptions.model.InsurancePackages;
import com.insurance.Customeroptions.model.InsurancePolicy;

import jakarta.servlet.http.HttpSession;

class InterfaceInsurancePolicyandPackageDAOImplTest {

	@Mock
	private JdbcTemplate jdbcTemplate;

	@Mock
	private HttpSession session;

	@InjectMocks
	private InterfaceInsurancePolicyandPackageDAOImpl dao;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void getAllInsurancePolicies() {
		// Arrange
		String sql = "SELECT * FROM insurancepolicies1";
		List<InsurancePolicy> expectedPolicies = createDummyInsurancePolicies();
		when(jdbcTemplate.query(sql, any(RowMapper.class))).thenReturn(expectedPolicies);

		// Act
		List<InsurancePolicy> result = dao.getAllInsurancePolicies();

		// Assert
		assertEquals(expectedPolicies, result);
	}

	@Test
	void getAllFAQS() {
		// Arrange
		String sql = "SELECT * FROM HealthInsuranceFAQs";
		List<Faq> expectedFAQs = createDummyFAQs();
		when(jdbcTemplate.query(sql, any(RowMapper.class))).thenReturn(expectedFAQs);

		// Act
		List<Faq> result = dao.getAllFAQS();

		// Assert
		assertEquals(expectedFAQs, result);
	}

	@Test
	void getCustomerInsurancePolicy() {
		// Arrange
		String sql = "SELECT * FROM insurancepolicies1 ";
		List<InsurancePolicy> expectedPolicies = createDummyInsurancePolicies();
		when(jdbcTemplate.query(sql, any(Object[].class), any(RowMapper.class))).thenReturn(expectedPolicies);

		// Act
		List<InsurancePolicy> result = dao.getCustomerInsurancePolicy(1);

		// Assert
		assertEquals(expectedPolicies, result);
	}

	@Test
	void getInsurancePackages() {
		// Arrange
		String sql = "SELECT * FROM InsurancePackages";
		List<InsurancePackages> expectedPackages = createDummyInsurancePackages();
		when(jdbcTemplate.query(sql, any(RowMapper.class))).thenReturn(expectedPackages);

		// Act
		List<InsurancePackages> result = dao.getInsurancePackages();

		// Assert
		assertEquals(expectedPackages, result);
	}

	@Test
	void addCustomer() {
		// Arrange
		FormData formData = createDummyFormData();

		// Mock jdbcTemplate.update() calls
		when(jdbcTemplate.update(any(String.class), any(Object[].class))).thenReturn(1);

		// Mock session attribute
		when(session.getAttribute("userId")).thenReturn(1L);

		// Act
		Long result = dao.addCustomer(formData);

		// Assert
		assertEquals(1L, result);

		// Verify that jdbcTemplate.update() was called 3 times
		verify(jdbcTemplate, times(3)).update(any(String.class), any(Object[].class));
	}

	@Test
	void getGeneralFAQS() {
		// Arrange
		String sql = "SELECT * FROM HealthInsuranceFAQs WHERE category='General'";
		List<Faq> expectedFAQs = createDummyFAQs();
		when(jdbcTemplate.query(sql, any(RowMapper.class))).thenReturn(expectedFAQs);

		// Act
		List<Faq> result = dao.getGeneralFAQS();

		// Assert
		assertEquals(expectedFAQs, result);
	}

	@Test
	void getCoverageandBenefitsFAQS() {
		// Arrange
		String sql = "SELECT * FROM HealthInsuranceFAQs WHERE category='Coverage and Benefits'";
		List<Faq> expectedFAQs = createDummyFAQs();
		when(jdbcTemplate.query(sql, any(RowMapper.class))).thenReturn(expectedFAQs);

		// Act
		List<Faq> result = dao.getCoverageandBenefitsFAQS();

		// Assert
		assertEquals(expectedFAQs, result);
	}

	// Helper methods to create dummy data

	private List<InsurancePolicy> createDummyInsurancePolicies() {
		List<InsurancePolicy> policies = new ArrayList<>();
		policies.add(new InsurancePolicy());
		policies.add(new InsurancePolicy());
		return policies;
	}

	private List<Faq> createDummyFAQs() {
		List<Faq> faqs = new ArrayList<>();
		faqs.add(new Faq((long) 1, "Question 1", "Answer 1", "General"));
		faqs.add(new Faq((long) 2, "Question 2", "Answer 2", "Coverage and Benefits"));
		return faqs;
	}

	private FormData createDummyFormData() {
		FormData formData = new FormData();
		formData.setfName("John");
		formData.setlName("Doe");
		formData.setDob((java.sql.Date) new Date());
		formData.setAddress("123 Main St");
		formData.setAadhar("1234567890");
		formData.setId(1);
		formData.setmName(new String[]{"Member 1", "Member 2"});
		formData.setRelationship(new String[]{"Relation 1", "Relation 2"});
		formData.setDob2((java.sql.Date[]) new Date[]{new Date(), new Date()});
		formData.setHealthHistory(new String[]{"History 1", "History 2"});
		formData.setSumassured((int) 500000.0);
		formData.setPaymodecount(12);
		return formData;
	}

	private List<InsurancePackages> createDummyInsurancePackages() {
		List<InsurancePackages> packages = new ArrayList<>();
		packages.add(new InsurancePackages());
		packages.add(new InsurancePackages());
		return packages;
	}
}

