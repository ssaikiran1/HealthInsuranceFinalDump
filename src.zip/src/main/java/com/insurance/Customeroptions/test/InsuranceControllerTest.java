package com.insurance.Customeroptions.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.file.Paths;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.Path;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.insurance.Customeroptions.contracts.InterfaceInsuranceRepository;
import com.insurance.Customeroptions.controller.InsuranceController;
import com.insurance.Customeroptions.model.Claim;
import com.insurance.Customeroptions.model.ClaimApplication;
import com.insurance.Customeroptions.model.ClaimBills;
import com.insurance.Customeroptions.model.ClaimDataDTO;
import com.insurance.Customeroptions.model.CustomerData;
import com.insurance.Customeroptions.model.InsurancePolicySchedule;
import com.insurance.Customeroptions.model.ReUpload;
import com.insurance.Customeroptions.model.Uploads;

import jakarta.servlet.http.HttpSession;

public class InsuranceControllerTest {

	@InjectMocks
	private InsuranceController insuranceController;

	@Mock
	private InterfaceInsuranceRepository insuranceRepository;

	@Mock
	private HttpSession session;

	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetActive() {
		int customerId = 5;
		when(insuranceRepository.getAllActivecount(customerId)).thenReturn(3);
		int result = insuranceController.getActive(customerId);
		assertEquals(3, result);
	}

	@Test
	public void testGetInsurancePolicyCount() {
		int customerId = 5;
		when(insuranceRepository.getInsurancePolicyCountForCustomer(customerId)).thenReturn(5);
		int result = insuranceController.getInsurancePolicyCount(customerId);
		assertEquals(5, result);
	}

	@Test
	public void testGetInsuranceFamilyCount() {
		int customerId = 5;
		when(insuranceRepository.getInsurancePolicyCountForFamily(customerId)).thenReturn(2);
		int result = insuranceController.getInsuranceFamilyCount(customerId);
		assertEquals(2, result);
	}

	@Test
	public void testGetInsuranceActiveMember() {
		int customerId = 5;
		when(insuranceRepository.getInsuranceActiveMember(customerId)).thenReturn(4);
		int result = insuranceController.getInsuranceActiveMember(customerId);
		assertEquals(4, result);
	}

	@Test
	public void testGetInsuranceActiveCoverage() {
		int customerId = 5;
		when(insuranceRepository.getInsuranceActiveCoverage(customerId)).thenReturn(10000);
		int result = insuranceController.getInsuranceActiveCoverage(customerId);
		assertEquals(10000, result);
	}

	@Test
	public void testGetInsurancePolicySum() {
		int customerId = 5;
		when(insuranceRepository.getInsurancePolicySum(customerId)).thenReturn(20000);
		int result = insuranceController.getInsurancePolicySum(customerId);
		assertEquals(20000, result);
	}

	@Test
	public void testListAllPolicySchedules() {
		int customerId = 5;
		List<InsurancePolicySchedule> policySchedules = new ArrayList<>();
		InsurancePolicySchedule policy1 = new InsurancePolicySchedule(/* initialize with data */);
		InsurancePolicySchedule policy2 = new InsurancePolicySchedule(/* initialize with data */);
		policySchedules.add(policy1);
		policySchedules.add(policy2);

		when(insuranceRepository.ListAllPolicySchedulesById(customerId)).thenReturn(policySchedules);

		List<InsurancePolicySchedule> result = insuranceController.listAllPolicySchedules(customerId);

		assertEquals(policySchedules, result);
	}

	@Test
	public void testGetUpcomingInsurancePolicyDate() {
		int customerId = 5;
		List<Date> upcomingDates = new ArrayList<>();
		upcomingDates.add(Date.valueOf("2023-11-01"));
		upcomingDates.add(Date.valueOf("2023-12-15"));

		when(insuranceRepository.getUpcomingInsuranceDate(customerId)).thenReturn(upcomingDates);

		List<Date> result = insuranceController.getUpcomingInsurancePolicyDate(customerId);

		assertEquals(upcomingDates, result);
	}

	@Test
	public void testGetLastPaidInsurancePolicyDate() {
		int customerId = 5;
		List<Date> lastPaidDates = new ArrayList<>();
		lastPaidDates.add(Date.valueOf("2024-01-31"));
		lastPaidDates.add(Date.valueOf("2024-02-29"));

		when(insuranceRepository.getLastPaidInsuranceDate(customerId)).thenReturn(lastPaidDates);

		String result = insuranceController.getLastPaidInsurancePolicyDate(customerId);

		assertEquals(lastPaidDates.toString(), result);
	}

	@Test
	public void testGetInsurancePolicyEXPDate() {
		int customerId = 5;
		List<Date> expirationDates = new ArrayList<>();
		expirationDates.add(Date.valueOf("2024-01-31"));
		expirationDates.add(Date.valueOf("2024-02-29"));

		when(insuranceRepository.getAllInsuranceEXPDates(customerId)).thenReturn(expirationDates);

		List<Date> result = insuranceController.getInsurancePolicyEXPDate(customerId);

		assertEquals(expirationDates, result);
	}

	@Test
	public void testGetInsurancePremiumMount() {
		int customerId = 5;
		List<Integer> premiumAmounts = new ArrayList<>();
		when(insuranceRepository.getInsurancePremiumAmount(customerId)).thenReturn(premiumAmounts);

		List<Integer> result = insuranceController.getInsurancePremiumMount(customerId);

		assertEquals(premiumAmounts, result);
	}

	@Test
	public void testGetInsurancePolicyDate() {
		int customerId = 5;
		List<Date> policyDates = new ArrayList<>();
		policyDates.add(Date.valueOf("2024-01-31"));
		policyDates.add(Date.valueOf("2024-02-29"));

		when(insuranceRepository.getAllInsuranceDates(customerId)).thenReturn(policyDates);

		List<Date> result = insuranceController.getInsurancePolicyDate(customerId);

		assertEquals(policyDates, result);
	}

	@Test
	public void testSaveCustomerData() {
		CustomerData customerData = new CustomerData();

		when(insuranceRepository.getCustIdByUserId(1L)).thenReturn(1);
		doNothing().when(insuranceRepository).saveCustomerData(customerData);

		insuranceController.saveCustomerData(customerData, mock(Model.class));
		verify(insuranceRepository, times(1)).saveCustomerData(customerData);

	}

	@Test
	public void testGetAllCustomers() {

		List<CustomerData> customers = new ArrayList<>();
		customers.add(new CustomerData());
		customers.add(new CustomerData());

		when(insuranceRepository.getAllCustomers()).thenReturn(customers);

		insuranceController.getAllCustomers();
		verify(insuranceRepository, times(1)).getAllCustomers();

	}

	@Test
	public void testSaveUserData() {

		when(insuranceRepository.saveUserData("testUser", "testPassword")).thenReturn(1L);


		insuranceController.saveUserData("testUser", "testPassword");
		verify(insuranceRepository, times(1)).saveUserData("testUser", "testPassword");

	}

	@Test
	public void testUserCredinitial() {


		when(insuranceRepository.getCustIdByUserId(1L)).thenReturn(1);
		when(insuranceRepository.userChecking("testUser", "testPassword", new ArrayList<>())).thenReturn(true);


		insuranceController.userCredinitial("testUser", "testPassword");
		verify(insuranceRepository, times(1)).userChecking("testUser", "testPassword", new ArrayList<>());

	}

	@Test
	public void testGetRegisterHospitalById() {

		when(insuranceRepository.getRegisterHospitalById(1)).thenReturn(5);


		insuranceController.getRegisterHospitalById(1);
		verify(insuranceRepository, times(1)).getRegisterHospitalById(1);

	}

	@Test
	public void testGetIndividualHospitalsById() {

		when(insuranceRepository.getIndividualHospitalsById(1)).thenReturn(3);


		insuranceController.getIndividualHospitalsById(1);
		verify(insuranceRepository, times(1)).getIndividualHospitalsById(1);

	}

	@Test
	public void testUpdateCustomers() {

		List<CustomerData> updatedCustomerData = Arrays.asList();

		when(insuranceRepository.updateCustomersData(updatedCustomerData)).thenReturn("Updated successfully");

		insuranceController.UpdateCustomers(updatedCustomerData);
		verify(insuranceRepository, times(1)).updateCustomersData(updatedCustomerData);

	}

	@Test
	public void testEmail() {

		when(insuranceRepository.sendmail("test@example.com")).thenReturn(123);


		insuranceController.email("test@example.com");
		verify(insuranceRepository, times(1)).sendmail("test@example.com");

	}

	@Test
	public void testReset() {

		when(insuranceRepository.resetpwd("test@example.com", "newPassword", "newPassword", 1L)).thenReturn(1);



		verify(insuranceRepository, times(1)).resetpwd("test@example.com", "newPassword", "newPassword", 1L);

	}

	@Test
	public void testClaimData1() {


		String[] documentNames = { "Document 1" };
		String[] claimAmount = { "100.0" };
		Claim claim = new Claim();
		ClaimApplication application = new ClaimApplication();
		Model model = mock(Model.class);

		when(insuranceRepository.checkPolicyIdStatus(anyInt())).thenReturn(false);
		when(insuranceRepository.checkRequestedAmount(anyInt(), anyDouble())).thenReturn(true);

		when(insuranceRepository.addClaim(anyInt(), anyDouble())).thenReturn(2);

		String result = insuranceController.claimData(null, documentNames, claimAmount, claim, application, model);

		assertEquals("Success", result);
		verify(insuranceRepository, times(1)).addClaimApplication(application);
		verify(insuranceRepository, times(1)).addClaim(anyInt(), anyDouble());

	}

	@Test
	public void testGetFamilyMembers() {

		int policyId = 30;

		List<String> familyMembers = Arrays.asList("John", "Jane", "Doe");

		when(insuranceRepository.getFamilyByPolicy(policyId)).thenReturn(familyMembers);

		List<String> result = insuranceController.getFamily(policyId);

		assertEquals(familyMembers, result);
		verify(insuranceRepository, times(1)).getFamilyByPolicy(policyId);

	}

	@Test
	public void testGetAllClaimsById() {

		Long customerId = (long) 8;

		ArrayList<Integer> claimIds = new ArrayList<>(Arrays.asList(1, 2, 3));

		when(insuranceRepository.getAllClaims(customerId)).thenReturn(claimIds);

		ArrayList<Integer> result = insuranceController.getAllClaimsById(customerId);

		assertEquals(claimIds, result);
		verify(insuranceRepository, times(1)).getAllClaims(customerId);

	}

	@Test
	public void testGetClaimById() {

		int claimId = 31;

		Claim dummyClaim = new Claim();

		when(insuranceRepository.getClaimByid(claimId)).thenReturn(dummyClaim);

		Claim result = insuranceController.getClaimById(claimId);

		assertEquals(dummyClaim, result);
		verify(insuranceRepository, times(1)).getClaimByid(claimId);

	}

	@Test
	public void testGetAllDataByClaimId() {

		int claimId = 31;

		Claim dummyClaim = new Claim();
		ClaimBills dummyClaimBill = new ClaimBills();
		Uploads dummyUpload = new Uploads();
		ReUpload dummyReupload = new ReUpload();
		int claimPolicyId = 2;
		List<String> patientNames = Arrays.asList("John", "Jane");

		ClaimDataDTO dummyClaimData = new ClaimDataDTO();
		dummyClaimData.setClaim(dummyClaim);
		dummyClaimData.setClaimBill(Arrays.asList(dummyClaimBill));
		dummyClaimData.setUploads(Arrays.asList(dummyUpload));
		dummyClaimData.setReuploads(Arrays.asList(dummyReupload));
		dummyClaimData.setClaimPolicyId(claimPolicyId);
		dummyClaimData.setPatientNames(patientNames);

		when(insuranceRepository.getClaimByid(claimId)).thenReturn(dummyClaim);
		when(insuranceRepository.getClaimBillById(claimId)).thenReturn(Arrays.asList(dummyClaimBill));
		when(insuranceRepository.getUploadByClaimId(claimId)).thenReturn(Arrays.asList(dummyUpload));
		when(insuranceRepository.getReUploadsByClaimId(claimId)).thenReturn(Arrays.asList(dummyReupload));
		when(insuranceRepository.getclaimPolicyIdByClaimId(claimId)).thenReturn(claimPolicyId);
		when(insuranceRepository.getPatientNameByPlocyId(claimPolicyId)).thenReturn(patientNames);

		ClaimDataDTO result = insuranceController.getAllDataByClaimId(claimId);

		// Assert the result or perform further verifications
		assertEquals(dummyClaimData, result);
		verify(insuranceRepository, times(1)).getClaimByid(claimId);
		verify(insuranceRepository, times(1)).getClaimBillById(claimId);
		verify(insuranceRepository, times(1)).getUploadByClaimId(claimId);
		verify(insuranceRepository, times(1)).getReUploadsByClaimId(claimId);
		verify(insuranceRepository, times(1)).getclaimPolicyIdByClaimId(claimId);
		verify(insuranceRepository, times(1)).getPatientNameByPlocyId(claimPolicyId);

	}

	@Test
	public void testGetFilteredClaims() {

		String status = "Approved";

		ArrayList<Claim> filteredClaims = new ArrayList<>(Arrays.asList(new Claim(), new Claim()));

		when(insuranceRepository.getFilteredClaims(status)).thenReturn(filteredClaims);

		ArrayList<Claim> result = insuranceController.getFilteredClaims(status);

		assertEquals(filteredClaims, result);
		verify(insuranceRepository, times(1)).getFilteredClaims(status);

	}

	@Test
	public void testClaimData() {

		MultipartFile[] files = new MultipartFile[2]; // Replace with your own MultipartFile objects
		String[] documentNames = { "Document1", "Document2" };
		String[] claimAmount = { "100.0", "200.0" };

		Claim claim = new Claim();
		claim.setClamIplcId(123);

		ClaimApplication application = new ClaimApplication();
		application.setClamIplcId(123);
		application.setClaimAmountRequested(300.0);

		when(insuranceRepository.checkPolicyIdStatus(123)).thenReturn(false);
		when(insuranceRepository.checkRequestedAmount(123, 300.0)).thenReturn(true);

		when(insuranceRepository.addClaim(123, 300.0)).thenReturn(456);

		String uploadDir = "src/main/resources/static/file";
		Path uploadDirPath = (Path) Paths.get(uploadDir);

		when((uploadDirPath)).thenReturn(uploadDirPath);

		String result = insuranceController.claimData(files, documentNames, claimAmount, claim, application, null);
		verify(insuranceRepository, times(1)).addClaimApplication(application);
		verify(insuranceRepository, times(1)).addClaim(123, 300.0);
		verify(insuranceRepository, times(2)).addClaimBills(any(ClaimBills.class));
		assertEquals("Success", result);
	}

	@Test
	public void testClaimDataWithNonActivePolicyException() {

		MultipartFile[] files = new MultipartFile[2]; // Replace with your own MultipartFile objects
		String[] documentNames = { "Document1", "Document2" };
		String[] claimAmount = { "100.0", "200.0" };

		Claim claim = new Claim();
		claim.setClamIplcId(123);

		ClaimApplication application = new ClaimApplication();
		application.setClamIplcId(123);
		application.setClaimAmountRequested(300.0);

		when(insuranceRepository.checkPolicyIdStatus(123)).thenReturn(true);

		String result = insuranceController.claimData(files, documentNames, claimAmount, claim, application, null);
		verify(insuranceRepository, times(0)).addClaimApplication(application);
		verify(insuranceRepository, times(0)).addClaim(123, 300.0);
		assertEquals("errorPage", result);

	}

	@Test
	public void testClaimDataWithCustomerRequestedAmountException() {

		MultipartFile[] files = new MultipartFile[2]; // Replace with your own MultipartFile objects
		String[] documentNames = { "Document1", "Document2" };
		String[] claimAmount = { "100.0", "200.0" };

		Claim claim = new Claim();
		claim.setClamIplcId(123);

		ClaimApplication application = new ClaimApplication();
		application.setClamIplcId(123);
		application.setClaimAmountRequested(300.0);

		when(insuranceRepository.checkPolicyIdStatus(123)).thenReturn(false);
		when(insuranceRepository.checkRequestedAmount(123, 300.0)).thenReturn(false);

		String result = insuranceController.claimData(files, documentNames, claimAmount, claim, application, null);
		verify(insuranceRepository, times(0)).addClaimApplication(application);
		verify(insuranceRepository, times(0)).addClaim(123, 300.0);
		assertEquals("errorPage", result);

	}

	@Test
	public void testAdduploadsFile() {
		int claimId = 21;
		MultipartHttpServletRequest request = mock(MultipartHttpServletRequest.class);
		insuranceController.adduploadsFile(claimId, request);
		verify(insuranceRepository, times(1)).storeData(eq(claimId), any());
	}

}
