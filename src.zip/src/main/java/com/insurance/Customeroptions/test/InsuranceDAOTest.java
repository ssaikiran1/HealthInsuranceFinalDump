package com.insurance.Customeroptions.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.sql.DataSource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;

import com.insurance.Customeroptions.dao.InsuranceDAO;
import com.insurance.Customeroptions.model.Claim;
import com.insurance.Customeroptions.model.ClaimApplication;
import com.insurance.Customeroptions.model.ClaimBills;
import com.insurance.Customeroptions.model.CustomerData;

class InsuranceDAOTest {

	@Mock
	private JdbcTemplate jdbcTemplate;

	private InsuranceDAO insuranceDAO;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this); // Initialize Mockito mocks
		insuranceDAO = new InsuranceDAO((DataSource) jdbcTemplate, null);
	}

	@Test
	void testGetInsurancePolicyCountForCustomer() {
		int customerId = 8;
		// Mock the result from the database
		int expectedResult = 5;

		int actualResult = insuranceDAO.getInsurancePolicyCountForCustomer(customerId);
		assertEquals(expectedResult, actualResult);
	}

	@Test
	void testGetInsurancePolicyCountForFamily() {
		int customerId = 8;
		// Mock the result from the database
		int expectedResult = 3;

		int actualResult = insuranceDAO.getInsurancePolicyCountForFamily(customerId);
		assertEquals(expectedResult, actualResult);
	}

	@Test
	void testGetApplicantRelation() {
		int customerId = 9;
		// Mock the result from the database
		List<String> expectedRelations = new ArrayList<>();

		expectedRelations.add("Spouse");
		expectedRelations.add("Child");
		expectedRelations.add("Parent");

		List<String> actualRelations = insuranceDAO.getApplicantRelation(customerId);
		assertEquals(expectedRelations.size(), actualRelations.size());
		// Add more assertions to compare relation data...
	}

	@Test
	void testSaveUserData() {
		String userName = "testUser";
		String password = "testPassword";

		int expectedResult = 1;

		long actualResult = insuranceDAO.saveUserData(userName, password);
		assertEquals(expectedResult, actualResult);
	}

	@Test
	void testUploadFileToDatabase() {
		Long userId = 5L;
		Long customerId = 25L;
		String fullPath = "testfile.pdf";
		String fileName = "testfile.pdf";
		insuranceDAO.uploadFileToDatabase(userId, customerId, fullPath, fileName);
	}

	@Test
	void testGetAllCustomersFromDao() {
		List<CustomerData> expectedCustomers = new ArrayList<>();

		expectedCustomers.add(new CustomerData());
		expectedCustomers.add(new CustomerData());

		List<CustomerData> actualCustomers = insuranceDAO.getAllCustomersFromDao();
		assertEquals(expectedCustomers.size(), actualCustomers.size());
	}

	@Test
	void testAddClaimBills() {
		ClaimBills bill = new ClaimBills();

		bill.setClam_id(1);
		bill.setClbl_document_title("Document Title");
		bill.setClbl_document_path("Document Path");
		bill.setClbl_claim_amount(1000.0);

		insuranceDAO.addClaimBills(bill);
	}

	@Test
	void testAddClaimApplication() {
		ClaimApplication application = new ClaimApplication();

		application.setClamIplcId(1);

		insuranceDAO.addClaimApplication(application);
	}

	@Test
	void testAddClaim() {
		int clamIplcId = 15;
		double claimAmountRequested = 1000.0;

		int expectedClamId = 123; // Replace with your expected clam_id

		int actualClamId = insuranceDAO.addClaim(clamIplcId, claimAmountRequested);
		assertEquals(expectedClamId, actualClamId);
	}

	@Test
	void testGetAllClaims() {
		Long customerId = 15L;

		List<Integer> expectedClaims = new ArrayList<>();

		expectedClaims.add(1);
		expectedClaims.add(2);
		expectedClaims.add(3);
		List<Integer> actualClaims = insuranceDAO.getAllClaims(customerId);
		assertEquals(expectedClaims.size(), actualClaims.size());
	}

	@Test
	void testGetFilteredClaims() {
		String status = "Pending";
		List<Claim> expectedClaims = new ArrayList<>();

		expectedClaims.add(new Claim());
		expectedClaims.add(new Claim());
		expectedClaims.add(new Claim());

		ArrayList<Claim> actualClaims = insuranceDAO.getFilteredClaims(status);
		assertEquals(expectedClaims.size(), actualClaims.size());
	}

	@Test
	void testGetClaimByid() {
		int clamIplcId = 20;
		new Claim();

		Claim actualClaim = insuranceDAO.getClaimByid(clamIplcId);
		assertNotNull(actualClaim);
	}

	@Test
	void testGetPdfFileNames() {
		List<String> expectedFileNames = Arrays.asList("file1.pdf", "file2.pdf", "file3.pdf");
		List<String> actualFileNames = insuranceDAO.getPdfFileNames();
		assertEquals(expectedFileNames.size(), actualFileNames.size());
	}

	@Test
	void testResetpwd() {
		String email = "test@example.com";
		String pwd = "newPassword";
		Long GsessionId = 5L;
		int expectedResult = 1;

		int actualResult = insuranceDAO.resetpwd(email, pwd, GsessionId);
		assertEquals(expectedResult, actualResult);
	}

	@Test
	void testUpdateCustomersData() {
		List<CustomerData> updatedCustomerData = new ArrayList<>();

		insuranceDAO.updateCustomersData(updatedCustomerData);
	}
}



