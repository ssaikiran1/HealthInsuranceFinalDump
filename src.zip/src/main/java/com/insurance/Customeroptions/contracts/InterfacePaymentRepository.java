package com.insurance.Customeroptions.contracts;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.insurance.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.insurance.Customeroptions.model.InsurancePolicyPayment;
import com.insurance.Customeroptions.model.NetworkHospitals;

public interface InterfacePaymentRepository {
	
	public boolean insertpayment(InsurancePolicyPayment p);
	
	public List<InsurancePolicyPayment> getAllIPPsData();
	
	public List<InsurancePolicyPayment> getAllFirstPP(int id) ;

	public boolean updateTransactionsId(int policyId, String newTransactionId, Date currentDate);
	
	public List<InsurancePolicyPayment> getAllTransactionsbyID(int custID);
	
	 public boolean insertIPCMdata(InsurancePolicyCoverageMembers p, int policyid);


	public List<InsurancePolicyCoverageMembers> getAllIpcmData();
	public ArrayList<NetworkHospitals> getAllHospitals();
	 public boolean checkTransactionLimitExceeded(int policyId) ;
	

}
