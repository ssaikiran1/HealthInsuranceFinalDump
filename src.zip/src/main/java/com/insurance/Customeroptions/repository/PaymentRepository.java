package com.insurance.Customeroptions.repository;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.insurance.Customeroptions.contracts.PaymentIntDAO;

import com.insurance.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.insurance.Customeroptions.model.InsurancePolicyPayment;
import com.insurance.Customeroptions.model.NetworkHospitals;
import com.insurance.Customeroptions.contracts.*;

@Repository
public class PaymentRepository implements InterfacePaymentRepository {
    @Autowired
    private PaymentIntDAO paymentdao;

    // Method to insert a payment record
    public boolean insertpayment(InsurancePolicyPayment p) {
        return paymentdao.createPayment(p);
    }

    // Method to get all insurance policy payment data
    public List<InsurancePolicyPayment> getAllIPPsData() {
        List<InsurancePolicyPayment> l1 = paymentdao.getAllInsurancePolicyPaymentsList();
        return l1;
    }

    // Method to get all first policy payments by customer ID
    public List<InsurancePolicyPayment> getAllFirstPP(int id) {
        List<InsurancePolicyPayment> l3 = paymentdao.getAllFirstPolicy(id);
        return l3;
    }

    // Method to update transaction ID
    public boolean updateTransactionsId(int policyId, String newTransactionId, Date currentDate) {
        return paymentdao.updateTransactionId(policyId, newTransactionId, currentDate);
    }

    // Method to get all transactions by customer ID
    public List<InsurancePolicyPayment> getAllTransactionsbyID(int custID) {
        List<InsurancePolicyPayment> l3 = paymentdao.getAllCustPayments(custID);
        return l3;
    }

    // Method to insert insurance policy coverage members data
    public boolean insertIPCMdata(InsurancePolicyCoverageMembers p, int policyid) {
        return paymentdao.InsertIPCM(p, policyid);
    }

    // Method to get all insurance policy coverage members data
    public List<InsurancePolicyCoverageMembers> getAllIpcmData() {
        List<InsurancePolicyCoverageMembers> l7 = paymentdao.getAllIPCMList();
        return l7;
    }

    // Method to get all network hospitals data
    public ArrayList<NetworkHospitals> getAllHospitals() {
        return paymentdao.getAllHopitals();
    }

    // Method to check if the transaction limit is exceeded for a policy
    public boolean checkTransactionLimitExceeded(int policyId) {
        int i = paymentdao.getCountNullTransId(policyId);
        if (i == 0) {
            return true;
        }
        return false;
    }
}
