package com.insurance.Customeroptions.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.insurance.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.insurance.Customeroptions.model.InsurancePolicyPayment;
import com.insurance.Customeroptions.model.NetworkHospitals;
import com.insurance.Customeroptions.rowmapper.*;
import com.insurance.Customeroptions.contracts.*;

@Component
public class CustomerPaymentDAO implements PaymentIntDAO {
	JdbcTemplate jdbcTemplate;

	@Autowired
	public CustomerPaymentDAO(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	private final String SQL_DISPLAY_NetworkHospitals = "SELECT * FROM NetworkHospitals";
	private final String SQL_DISPLAY_insurancepayments = "SELECT * FROM InsurancePolicyPayments";

	private final String SQL_DISPLAY_NETWORKHOSPITALSBYCITY = "SELECT * FROM NetworkHospitals WHERE hosp_city = ?";
	private final String SQL_DISPLAY_BYCITY = "SELECT * FROM NetworkHospitals WHERE hosp_grade = ?";
	private final String SQL_DISPLAY_FACILITY = "SELECT * FROM NetworkHospitals WHERE hosp_facility = ?";
	private final String SQL_DISPLAY_ID = "SELECT * FROM NetworkHospitals WHERE hosp_id = ?";
	private final String SQL_INSERT_PAYMENT = "INSERT INTO InsurancePolicyPayments (inpp_iplc_id, inpp_trans_id, inpp_amount, inpp_paymode,inpp_date) VALUES (?,?, ?, ?, ?,?)";

	private final String SQL_UPDATE_TRANSACTIONID = "UPDATE InsurancePolicyPayments\r\n"
			+ "	SET inpp_trans_id = ?, inpp_date = ?\r\n" + "	WHERE inpp_iplc_id = ? \r\n"
			+ "	  AND inpp_trans_id IS NULL \r\n" + "	  AND inpp_date IS NULL \r\n" + "	  AND iplc_sindex = (\r\n"
			+ "	    SELECT MIN(iplc_sindex) \r\n" + "	    FROM InsurancePolicyPayments \r\n"
			+ "	    WHERE inpp_iplc_id = ?\r\n" + "	      AND inpp_trans_id IS NULL \r\n"
			+ "	      AND inpp_date IS NULL\r\n" + "	  )";
	private final String SQL_DISPLAY_FIRSTPP = "SELECT * FROM InsurancePolicyPayments WHERE inpp_iplc_id = ? LIMIT 1";

	private final String SQL_DISPLAY_TRANSACTIONSBYCUSTID = "SELECT\r\n" + "    IPP.inpp_id,\r\n"
			+ "    IPP.inpp_iplc_id,\r\n" + "    IPP.inpp_trans_id,\r\n" + "    IPP.inpp_amount,\r\n"
			+ "    IPP.inpp_paymode,\r\n" + "    IPP.inpp_date\r\n" + "FROM\r\n"
			+ "    InsurancePolicyPayments AS IPP\r\n" + "WHERE\r\n" + "    IPP.inpp_iplc_id IN (\r\n"
			+ "        SELECT iplc_id\r\n" + "        FROM InsurancePolicies1\r\n"
			+ "        WHERE iplc_cust_id = ?\r\n" + "    );\r\n";

	private String SQL_INSERT_MEMBER = "INSERT INTO InsurancePolicyCoverageMembers (iplc_id, ipcm_membername, ipcm_relation, ipcm_dob, ipcm_gender, ipcm_healthhistory) SELECT p.iplc_id, ?, ?, ?, ?, ? FROM InsurancePolicies1 p WHERE p.iplc_id = ?";

	private final String SQL_DISPLAY_IPCMLISTS = "SELECT * FROM InsurancePolicyCoverageMembers";
	private final String SQL_DISPLAY_Exception = "SELECT COUNT(*) \r\n" + "FROM insurancepolicypayments \r\n"
			+ "WHERE inpp_trans_id IS NULL \r\n" + "AND inpp_iplc_id = ?";

	@Override
    public boolean createPayment(InsurancePolicyPayment payment) {
        // Insert a new payment record into the database
        return jdbcTemplate.update(SQL_INSERT_PAYMENT, payment.getPolicyId(), payment.getTransactionId(),
                payment.getAmount(), payment.getPaymentMode(), payment.getTransDate()) > 0;
    }

    @Override
    public List<InsurancePolicyPayment> getAllInsurancePolicyPaymentsList() {
        // Retrieve all insurance policy payments from the database
        return jdbcTemplate.query(SQL_DISPLAY_insurancepayments, new InsurancePolicyPaymentMapper());
    }

    @Override
    public List<InsurancePolicyPayment> getAllFirstPolicy(int policyId) {
        // Retrieve the first insurance policy payment for a given policy ID
        return jdbcTemplate.query(SQL_DISPLAY_FIRSTPP, new InsurancePolicyPaymentMapper(), policyId);
    }

    @Override
    public boolean updateTransactionId(int policyId, String newTransactionId, Date transdate) {
        // Update the transaction ID and transaction date for a payment record
        return jdbcTemplate.update(SQL_UPDATE_TRANSACTIONID, newTransactionId, transdate, policyId, policyId) > 0;
    }

    @Override
    public List<InsurancePolicyPayment> getAllCustPayments(int custId) {
        // Retrieve all payments for a customer based on their customer ID
        return jdbcTemplate.query(SQL_DISPLAY_TRANSACTIONSBYCUSTID, new InsurancePolicyPaymentMapper(), custId);
    }

    @Override
    public boolean InsertIPCM(InsurancePolicyCoverageMembers ipcm, int policyid) {
        // Insert a new insurance policy coverage member record into the database
        return jdbcTemplate.update(SQL_INSERT_MEMBER, ipcm.getIpcmMemberName(), ipcm.getIpcmRelation(),
                ipcm.getIpcmDob(), ipcm.getIpcmGender(), ipcm.getIpcmHealthHistory(), policyid) > 0;
    }

    @Override
    public List<InsurancePolicyCoverageMembers> getAllIPCMList() {
        // Retrieve all insurance policy coverage members from the database
        return jdbcTemplate.query(SQL_DISPLAY_IPCMLISTS, new InsurancePolicyCoverageMemberMapper());
    }

    public ArrayList<NetworkHospitals> getAllHopitals() {
        // Retrieve a list of all network hospitals from the database
        String sql = "SELECT * FROM NetworkHospitals";
        return (ArrayList<NetworkHospitals>) jdbcTemplate.query(sql, new NetworkHospitalRowMapper());
    }

    @Override
    public int getCountNullTransId(int policyId) {
        // Get the count of payment records with null transaction IDs for a given policy ID
        return jdbcTemplate.queryForObject(SQL_DISPLAY_Exception, Integer.class, policyId);
    }

}
