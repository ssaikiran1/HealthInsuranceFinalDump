package com.insurance.Customeroptions.dao;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.insurance.Customeroptions.contracts.InterfaceInsuranceDAO;
import com.insurance.Customeroptions.model.Claim;
import com.insurance.Customeroptions.model.ClaimApplication;
import com.insurance.Customeroptions.model.ClaimBills;
import com.insurance.Customeroptions.model.CustomerData;
import com.insurance.Customeroptions.model.InsuranceApiError;
import com.insurance.Customeroptions.model.InsurancePolicy;
import com.insurance.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.insurance.Customeroptions.model.InsurancePolicySchedule;
import com.insurance.Customeroptions.model.ReUpload;
import com.insurance.Customeroptions.model.Uploads;
import com.insurance.Customeroptions.model.UserData;
import com.insurance.Customeroptions.rowmapper.ClaimBillsRowMapper;
import com.insurance.Customeroptions.rowmapper.ClaimMapper;
import com.insurance.Customeroptions.rowmapper.CustomerDataRowMapper;
import com.insurance.Customeroptions.rowmapper.InsurancePolicyCoverageMemberMapper;
import com.insurance.Customeroptions.rowmapper.InsurancePolicyScheduleRowMapper;
import com.insurance.Customeroptions.rowmapper.ReUploadRowMapper;
import com.insurance.Customeroptions.rowmapper.UploadsRowMapper;
import com.insurance.Customeroptions.rowmapper.UsersDataRowMapper;

import jakarta.servlet.http.HttpSession;

@Component
public class InsuranceDAO implements InterfaceInsuranceDAO {
	JdbcTemplate jdbcTemplate;
	HttpSession session;

	@Autowired
	public InsuranceDAO(DataSource dataSource, HttpSession session) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		this.session = session;
	}

	// SQL Queries
	private final String SQL_POLICY_COUNT = "SELECT COUNT(*) FROM InsurancePolicies1 WHERE iplc_cust_id = ?";
	private final String SQL_POLICY_FAMILYCOUNT = "SELECT iplc_nom_insured FROM InsurancePolicies1 WHERE iplc_cust_id = ? LIMIT 1";
	private final String SQL_DISPLAY_ACTIVECOUNT = "SELECT COUNT(*) FROM InsurancePolicies1 WHERE iplc_expdate > iplc_cdate AND iplc_cust_id = ?";
	private final String SQL_POLICY_SUM = "select sum(iplc_sum_assured) from InsurancePolicies1 where iplc_cust_id=?";

	private final String SQL_POLICY_DATE = "select iplc_applicable_date from InsurancePolicies1 where iplc_cust_id=? limit 1";
	private final String SQL_POLICY_EXDATE = "select iplc_expdate from InsurancePolicies1 where iplc_cust_id=? limit 1";
	private final String SQL_POLICY_PREAMOUNT = "select iplc_yrly_prem_amount from InsurancePolicies1 where iplc_cust_id=? limit 1";
	private final String SQL_POLICY_NAME = "select iplc_applicant_name from InsurancePolicies1 where iplc_cust_id=? limit 1";
	private final String SQL_POLICY_RELATION = "select iplc_applicant_relation from InsurancePolicies1 where iplc_cust_id=?";
	private String SQL_GET_CLAIMS = "select c.clam_id from _claims c , insurancepolicies1 p where ( c.clam_iplc_id = p.iplc_id )\r\n"
			+ "			and\r\n" + "	( p.iplc_cust_id = ?)";
	private String SQL_GET_CLAIM_BY_ID = "select * from  _claims where clam_id=?";
	private String SQL_INSERT_CLAIM = "insert into _claims(clam_source,clam_type,clam_date,clam_amount_requested,clam_iplc_id) values(?,?,?,?,?)";
	private String SQL_INSERT_CLAIMBill = "insert into claim_bills(clam_id,clbl_document_title,clbl_document_path,clbl_claim_amount) values(?,?,?,?)";
	private String SQL_GET_FILTERED_CLAIMS = "select * from  _claims where clam_status=?";

	// Method to get the count of insurance policies for a customer
	@Override
	public int getInsurancePolicyCountForCustomer(int customerId) {
		return jdbcTemplate.queryForObject(SQL_POLICY_COUNT, Integer.class, customerId);
	}

	// Method to get the count of insurance policies for a family
	@Override
	public int getInsurancePolicyCountForFamily(int customerId) {
		return jdbcTemplate.queryForObject(SQL_POLICY_FAMILYCOUNT, Integer.class, customerId);
	}

	// Method to get the total sum of insurance policies for a customer
	@Override
	public int getInsuranceSum(int customerId) {
		return jdbcTemplate.queryForObject(SQL_POLICY_SUM, Integer.class, customerId);
	}

	// Method to get the count of all active insurance policies
	@Override
	public int getAllActivecountList(int customerId) {
		return jdbcTemplate.queryForObject(SQL_DISPLAY_ACTIVECOUNT, Integer.class, customerId);
	}

	// Method to get premium amounts of insurance policies for a customer
	@Override
	public List<Integer> getInsurancePremium(int customerId) {
		return jdbcTemplate.queryForList(SQL_POLICY_PREAMOUNT, Integer.class, customerId);
	}

	// Method to get insurance policy dates for a customer
	@Override
	public List<Date> getInsuranceDates(int customerId) {
		return jdbcTemplate.queryForList(SQL_POLICY_DATE, Date.class, customerId);
	}

	// Method to get insurance policy expiration dates for a customer
	@Override
	public List<Date> getInsuranceEXPDates(int customerId) {
		return jdbcTemplate.queryForList(SQL_POLICY_EXDATE, Date.class, customerId);
	}

	// Method to get applicant names for insurance policies of a customer
	@Override
	public List<String> getApplicantName(int customerId) {
		return jdbcTemplate.queryForList(SQL_POLICY_NAME, String.class, customerId);
	}

	// Method to get applicant relations for insurance policies of a customer
	@Override
	public List<String> getApplicantRelation(int customerId) {
		return jdbcTemplate.queryForList(SQL_POLICY_RELATION, String.class, customerId);
	}

	// Method to save user data
	@Override
	public long saveUserData(String userName, String password) {
		java.util.Date currentDate = new java.util.Date();
		Date sqlCurrentDate = new Date(currentDate.getTime());
		String userStatus = "AC";
		String userType = "CUST";
		String insertSql = "INSERT INTO users (user_name, user_cdate, user_pwd, user_type, user_status) "
				+ "VALUES (?, ?, ?, ?, ?)";
		return jdbcTemplate.update(insertSql, userName, sqlCurrentDate, password, userType, userStatus);
	}

	// Method to save customer data
	@Override
	public void saveCustomerData(CustomerData customerData) {
		String sql = "INSERT INTO Customers (cust_fname, cust_lname, cust_dob, cust_address, cust_gender, cust_cdate, cust_aadhar, cust_status, cust_luudate, cust_luuser, cust_user_id) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		jdbcTemplate.update(sql, customerData.getCust_fname(), customerData.getCust_lname(), customerData.getCust_dob(),
				customerData.getCust_address(), String.valueOf(customerData.getCust_gender()),
				customerData.getCust_cdate(), customerData.getCust_aadhar(), customerData.getCust_status(),
				customerData.getCust_luudate(), customerData.getCust_luuser(), customerData.getCust_user_id());
	}

	// Method to get all customers
	@Override
	public List<CustomerData> getAllCustomersFromDao() {
		return jdbcTemplate.query("SELECT * FROM Customers", new CustomerDataRowMapper());
	}

	// Method to get all users
	@Override
	public List<UserData> getAllUsersFromDao() {
		return jdbcTemplate.query("SELECT * FROM Users", new UsersDataRowMapper());
	}

	// Method to upload a file to the server
	@Override
	public String uploadFileToDao(MultipartFile file) {
		String uploadDir = "src/main/resources/static/file";

		try {
			String fileName = StringUtils.cleanPath(file.getOriginalFilename());
			Files.createDirectories(Paths.get(uploadDir));
			Path targetLocation = Paths.get(uploadDir).resolve(fileName);
			Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
			String fullPath = targetLocation.toAbsolutePath().toString();
			Long userId = (Long) session.getAttribute("userId");
			Long customerId = (Long) session.getAttribute("customerId");
			uploadFileToDatabase(userId, customerId, fullPath, fileName);
			return fileName;
		} catch (IOException ex) {
			System.out.println(ex);
			return null;
		}
	}

	// Method to upload file details to the database
	public void uploadFileToDatabase(Long userId, Long customerId, String fullPath, String fileName) {
		String sql = "INSERT INTO fileUploadData (userId, customerId, fullPath, fileName) VALUES (?, ?, ?, ?)";
		jdbcTemplate.update(sql, userId, customerId, fullPath, fileName);
	}

	// Method to get PDF file names
	@Override
	public List<String> getPdfFileNames() {
		String uploadDir = "src/main/resources/static/file";
		List<String> pdfFileNames = new ArrayList<>();
		File directory = new File(uploadDir);

		if (directory.exists() && directory.isDirectory()) {
			File[] files = directory.listFiles();

			if (files != null) {
				for (File file : files) {
					if (file.isFile() && file.getName().toLowerCase().endsWith(".pdf")) {
						pdfFileNames.add(file.getName());
					}
				}
			}
		}
		return pdfFileNames;
	}

	// Method to reset a password
	@Override
	public int resetpwd(String email, String pwd, Long GsessionId) {
		String sql = "UPDATE updatePasswordTable SET username = ?, password = ? WHERE userId = ?";
		return jdbcTemplate.update(sql, email, pwd, GsessionId);
	}

	// Method to update customer data
	@Override
	public void updateCustomersData(List<CustomerData> updatedCustomerData) {
		for (CustomerData customer : updatedCustomerData) {
			String deleteSql = "DELETE FROM Customers WHERE cust_id = ?";
			jdbcTemplate.update(deleteSql, customer.getCust_id());

			String insertSql = "INSERT INTO Customers (cust_id, cust_fname, cust_lname, cust_dob, "
					+ "cust_address, cust_gender, cust_cdate, cust_aadhar, cust_status, "
					+ "cust_luudate, cust_luuser) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			jdbcTemplate.update(insertSql, customer.getCust_id(), customer.getCust_fname(), customer.getCust_lname(),
					customer.getCust_dob(), customer.getCust_address(), customer.getCust_gender(),
					customer.getCust_cdate(), customer.getCust_aadhar(), customer.getCust_status(),
					customer.getCust_luudate(), customer.getCust_luuser());
		}
	}

	// Method to get all insurance policy schedules by ID
	@Override
	public List<InsurancePolicySchedule> getAllScheduleById(int id) {
		String sql = "SELECT * \r\n" + "FROM \r\n" + "InsurancePolicySchedule \r\n" + "WHERE iplc_id in (\r\n"
				+ " SELECT iplc_id FROM insurancepolicies1 WHERE iplc_cust_id = ? )";
		return jdbcTemplate.query(sql, new InsurancePolicyScheduleRowMapper(), new Object[] { id });
	}

	public int duplicatePolicyCreation(InsurancePolicy e) throws InsuranceApiError {
		String query = "SELECT COUNT(*) FROM insurancepolicies1 WHERE "
				+ "iplc_cust_id=? AND iplc_sum_assured=? AND iplc_yrly_prem_amount=? "
				+ "AND iplc_nom_insured=? AND iplc_insp_id=? AND iplc_paymode_count=? AND iplc_agnt_id=? and CURRENT_DATE + INTERVAL '1 month'<=iplc_expdate";

		int count = jdbcTemplate.queryForObject(query, Integer.class, e.getIplc_cust_id(), e.getIplc_sum_assured(),
				e.getIplc_yrly_prem_amount(), e.getIplc_nom_insured(), e.getIplc_insp_id(), e.getIplc_paymode_count(),
				e.getIplc_agnt_id());

		if (count != 0) {
			throw new InsuranceApiError(1, "Sorry, this policy is already existing");
		}

		return count;
	}

	// Method to add claim bills
	@Override
	public void addClaimBills(ClaimBills bill) {
		jdbcTemplate.update(SQL_INSERT_CLAIMBill, bill.getClam_id(), bill.getClbl_document_title(),
				bill.getClbl_document_path(), bill.getClbl_claim_amount());
	}

	// Method to add claim application
	@Override
	public void addClaimApplication(ClaimApplication application) {
		String query = "INSERT INTO insurance_claim(policy_id,member_index,relation,joined_date,patient_name,date_of_birth,gender,contact_number,address,disease,diagnosis,treatment,claimAmount,hosp_name) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Object[] values = { application.getClamIplcId(), application.getMemberIndex(), application.getRelation(),
				application.getJoinedDate(), application.getPatientName(), application.getDateOfBirth(),
				application.getGender(), application.getContactNumber(), application.getAddress(),
				application.getDisease(), application.getDiagnosis(), application.getTreatment(),
				application.getClaimAmountRequested(), "Service" };
		jdbcTemplate.update(query, values);
	}

	// Method to add a claim
	@Override
	public int addClaim(int clamIplcId, double claimAmountRequested) {
		LocalDate currentDate = LocalDate.now();
		java.sql.Date sqlDate = java.sql.Date.valueOf(currentDate);
		jdbcTemplate.update(SQL_INSERT_CLAIM, "INDI", "IND", sqlDate, claimAmountRequested, clamIplcId);
		return jdbcTemplate.queryForObject("select clam_id from _claims order by clam_id desc limit 1 ", Integer.class);
	}

	// Method to get all claims
	// @Override
	// public String getAllClaims(Long customerId) {
	// return jdbcTemplate.queryForObject(SQL_GET_CLAIMS,new Object[] { customerId } , String.class);
	// }
	@Override
	public List<Integer> getAllClaims(Long customerId) {
		return jdbcTemplate.queryForList(SQL_GET_CLAIMS, new Object[] { customerId }, Integer.class);
	}

	// Method to get filtered claims by status
	@Override
	public ArrayList<Claim> getFilteredClaims(String status) {
		return (ArrayList<Claim>) jdbcTemplate.query(SQL_GET_FILTERED_CLAIMS, new Object[] { status },
				new ClaimMapper());
	}

	// Method to get a claim by ID
	@Override
	public Claim getClaimByid(int clamIplcId) {
		return jdbcTemplate.queryForObject(SQL_GET_CLAIM_BY_ID, new Object[] { clamIplcId }, new ClaimMapper());
	}

	// Method to get insurance policy coverage members
	@Override
	public List<InsurancePolicyCoverageMembers> getPoliMem() {
		return jdbcTemplate.query(
				"SELECT iplc_id,ipcm_mindex,ipcm_membername,ipcm_relation, ipcm_dob, ipcm_gender,ipcm_healthhistory FROM insurancepolicycoveragemembers",
				new InsurancePolicyCoverageMemberMapper());
	}

	// Method to get customer ID by user ID
	@Override
	public int getCustIdByUserId(Long userId) {
		String sql = "SELECT COALESCE(MAX(cust_id), 0) AS cust_id\r\n" + "FROM Customers\r\n"
				+ "WHERE cust_user_id = ?\r\n" + "limit 1;";
		return jdbcTemplate.queryForObject(sql, new Object[] { userId }, Integer.class);
	}

	// Method to add required uploads
	@Override
	public void addRequiredUploads(ReUpload upload) {
		String query = "INSERT INTO reuploads(claimId,name,type,Status,description) values(?,?,?,?,?)";
		Object[] values = { upload.getClaimId(), upload.getName(), upload.getType(), upload.getStatus(),
				upload.getDescription() };
		jdbcTemplate.update(query, values);
	}

	// Method to get all reuploads by claim ID
	@Override
	public List<ReUpload> getAllReUploads(int id) {
		return jdbcTemplate.query("SELECT * FROM reuploads WHERE status is null AND claimId=" + id,
				new ReUploadRowMapper());
	}

	// Method to add uploads
	@Override
	public void addUploads(Uploads up) {
		String query = "INSERT INTO uploads(uploadId,reuploadId,claimId,data,type) values(?,?,?,?,?)";
		Object[] values = { up.getUploadId(), up.getReUploadId(), up.getClaimId(), up.getData(), up.getType() };
		jdbcTemplate.update(query, values);
	}

	// Method to get all uploads by claim ID
	@Override
	public List<Uploads> getAllUploads(int claimId) {
		return jdbcTemplate.query("SELECT * FROM uploads WHERE claimId=" + claimId, new UploadsRowMapper());
	}

	// Method to get all claim bills
	@Override
	public List<ClaimBills> getAllClaimBills() {
		String sql = "SELECT * FROM Claim_bills";
		return jdbcTemplate.query(sql, new ClaimBillsRowMapper());
	}

	// Method to update status
	@Override
	public void updateStatus(int claimId) {
		String sql = "UPDATE reuploads SET status = 'uploaded' WHERE claimid = ?";
		jdbcTemplate.update(sql, claimId);
	}

	// Method to get upload file by ID
	@Override
	public Uploads getAllUploadFileById(int id) {
		String sql = "SELECT * FROM Uploads WHERE claimid=?";
		return jdbcTemplate.queryForObject(sql, new Object[] { id }, new UploadsRowMapper());
	}

	@Override
	public boolean checkPolicyIdStatus(int policyId) {
		String sql = "select count(*) from insurancepolicies1 where iplc_id=" + policyId + " and iplc_status='pending'";
		return jdbcTemplate.queryForObject(sql, Integer.class) > 0;
	}

	@Override
	public Boolean checkRequestedAmount(int pid, double requestedClaimAmount) {

		double totalProcessedAmountClaimed;
		if (jdbcTemplate.queryForObject("select sum(clam_processed_amount) from _claims where clam_iplc_id=?",
				Double.class, pid) != null)
			totalProcessedAmountClaimed = jdbcTemplate.queryForObject(
					"select sum(clam_processed_amount) from _claims where clam_iplc_id=?", Double.class, pid);
		else
			totalProcessedAmountClaimed = 0;
		double packageAmount = jdbcTemplate
				.queryForObject("select iplc_sum_assured from Insurancepolicies1 where iplc_id=?", Double.class, pid);
		if (totalProcessedAmountClaimed + requestedClaimAmount > packageAmount)
			return false;
		return true;
	}

	@Override
	public int getInsuranceActiveMember(int customerId) {
		// Create a SQL query to count members in insurancepolicycoveragemembers
		String sqlQuery = "SELECT COUNT(*) FROM insurancepolicycoveragemembers "
				+ "WHERE iplc_id IN (SELECT iplc_id FROM insurancepolicies1 WHERE iplc_cust_id = ?)";

		// Use a JDBC template to execute the query and return the count
		return jdbcTemplate.queryForObject(sqlQuery, Integer.class, customerId);
	}

	@Override
	public int getPolicyId(int customerId) {
		System.out.println(customerId + "sai");
		// Create a SQL query to policy id insurancepolicycoveragemembers
		String sqlQuery = "SELECT iplc_id FROM insurancepolicycoveragemembers "
				+ "WHERE iplc_id IN (SELECT iplc_id FROM insurancepolicies1 WHERE iplc_cust_id = ?)";

		return jdbcTemplate.queryForObject(sqlQuery, new Object[] { customerId }, Integer.class);
	}

	@Override
	public int getInsuranceActiveCoverage(int customerId) {
		// Create a SQL query to count members in insurancepolicycoveragemembers
		String sqlQuery = "select sum(iplc_sum_assured) from InsurancePolicies1 where iplc_cust_id=? AND iplc_expdate > iplc_cdate";
		return jdbcTemplate.queryForObject(sqlQuery, Integer.class, customerId);
	}

	@Override
	public int getRegisterHospitalById(int customerId) {
		String sqlQuery = "SELECT COUNT(*) FROM _Claims "
				+ "WHERE clam_iplc_id IN (SELECT iplc_id FROM insurancepolicies1 WHERE iplc_cust_id = ?) "
				+ "AND clam_source = 'HSPT'";

		return jdbcTemplate.queryForObject(sqlQuery, Integer.class, customerId);
	}

	@Override
	public int getIndividualHospitalsById(int customerId) {
		String sqlQuery = "SELECT COUNT(*) FROM _Claims "
				+ "WHERE clam_iplc_id IN (SELECT iplc_id FROM insurancepolicies1 WHERE iplc_cust_id = ?) "
				+ "AND clam_source = 'INDI'";

		return jdbcTemplate.queryForObject(sqlQuery, Integer.class, customerId);
	}

	@Override
	public List<Date> getUpcomingInsuranceDates(int customerId) {
		String SQL_POLICY_UPCOMING_DATE = "select\r\n" + "iplc_date \r\n" + "from \r\n" + "insurancepolicyschedule \r\n"
				+ "where \r\n" + "	iplc_id = (select iplc_id from insurancepolicies1 where iplc_cust_id = ? "
				+ " LIMIT 1)\r\n" + "	 	and \r\n" + "	iplc_paid_date is null\r\n" + "order by iplc_date\r\n"
				+ "limit 1";
		return jdbcTemplate.queryForList(SQL_POLICY_UPCOMING_DATE, Date.class, customerId);
	}

	@Override
	public List<Date> getLastPaidInsuranceDates(int customerId) {
		String SQL_POLICY_LAST_PAID_DATE = "SELECT iplc_date\r\n" + "FROM insurancepolicyschedule\r\n" + "WHERE\r\n"
				+ "    iplc_id = (\r\n" + "        SELECT iplc_id\r\n" + "        FROM insurancepolicies1\r\n"
				+ "        WHERE iplc_cust_id = ? LIMIT 1\r\n" + "    )\r\n" + "    AND iplc_paid_date IS NOT NULL\r\n"
				+ "ORDER BY iplc_date DESC\r\n" + "LIMIT 1;\r\n" + "";
		return jdbcTemplate.queryForList(SQL_POLICY_LAST_PAID_DATE, Date.class, customerId);
	}

	@Override
	public List<ClaimBills> getClaimBillById(int clamId) {
		String sql = "SELECT * FROM claim_bills WHERE clam_id = ?";
		return jdbcTemplate.query(sql, new Object[] { clamId }, new ClaimBillsRowMapper());
	}

	@Override
	public List<Uploads> getUploadByClaimId(int clamId) {
		String sql = "SELECT * FROM uploads WHERE claimId = ?";

		return jdbcTemplate.query(sql, new Object[] { clamId }, new UploadsRowMapper());
	}

	@Override
	public List<ReUpload> getReUploadsByClaimId(int clamId) {
		String sql = "SELECT * FROM reuploads WHERE claimId = ?";

		return jdbcTemplate.query(sql, new Object[] { clamId }, new ReUploadRowMapper());
	}

	@Override
	public int getclaimPolicyIdByClaimId(int clamId) {
		String sql = "SELECT clam_iplc_id FROM _claims WHERE clam_id = ?";

		// Use the queryForObject method to retrieve the integer value
		return jdbcTemplate.queryForObject(sql, new Object[] { clamId }, Integer.class);
	}

	@Override
	public List<String> getPatientNameByPlocyId(int claimPolicyId) {
		String sql = "SELECT patient_name FROM insurance_claim WHERE policy_id = ?";

		return jdbcTemplate.queryForList(sql, new Object[] { claimPolicyId }, String.class);
	}

}
