package com.insurance.insuranceCompany.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.insurance.insuranceCompany.contract.InsuranceScheduleDAOInterface;
import com.insurance.insuranceCompany.model.InsurancePolicy;
import com.insurance.insuranceCompany.model.InsurancePolicySchedule;

@Repository
public class InsuranceRepositorySch {
	@Autowired
	private InsuranceScheduleDAOInterface insuranceScheduleDAOInterface;

	// To get all policy list
	public List<InsurancePolicy> listAllPolicy() {
		List<InsurancePolicy> pack = insuranceScheduleDAOInterface.getAllPolicies();
		return pack;
	}

	// To get List of all Schedules
	public List<InsurancePolicySchedule> listAllPolicySchedules() {
		List<InsurancePolicySchedule> s = insuranceScheduleDAOInterface.getAllSchedule();
		return s;
	}

	// To get list of all Schedules for a particular id
	public List<InsurancePolicySchedule> listAllPolicySchedulesById(int id) {
		List<InsurancePolicySchedule> s = insuranceScheduleDAOInterface.getAllScheduleById(id);
		return s;
	}

	// to Update Status for a particular policy for policy Approval
	public int updateNewPolicy(InsurancePolicy u) {
		return insuranceScheduleDAOInterface.updateStatus(u);
	}

	// To get number of months a particular id does not paid the policy
	public int listNonStatusPayments(int id) {
		return insuranceScheduleDAOInterface.getNonPaymentStatus(id);
	}

	// to get distinct policy id
	public List<Integer> findDistinctIds() {
		return insuranceScheduleDAOInterface.findDistinctIplcIds();
	}
}
