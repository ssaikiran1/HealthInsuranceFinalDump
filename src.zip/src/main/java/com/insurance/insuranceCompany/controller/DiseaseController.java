package com.insurance.insuranceCompany.controller;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.insurance.insuranceCompany.contract.DiseaseRepositoryInterface;
import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.service.DiseaseService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/insurance")
public class DiseaseController {

	@Autowired
	DiseaseRepositoryInterface dri;

	@Autowired
	HttpSession session;

	@Autowired
	DiseaseService ds;

	// Initialize a logger for this controller
	private final Logger logger;

	public DiseaseController(Logger diseaseControllerLogger) {
		this.logger = diseaseControllerLogger;
	}

	// Handle GET request to retrieve all diseases
	@GetMapping("/getDisease")
	public String getAllDisease(Model model) {
		try {
			logger.trace("Entering getAllDisease method");

			// Check if the user is logged in, if not, redirect to the login page
			Object lc = session.getAttribute("login");
			if (lc == null || (int) lc == 0) {
				model.addAttribute("noaccess", "you need to login first");
				model.addAttribute("login", new Login());
				return "loginPage";
			}

			// Get all diseases and add them to the model
			model.addAttribute("diseases", ds.getAllDisease());

			logger.info("Retrieved all diseases successfully");

			// Return the view for displaying diseases
			return "Disease";
		} catch (Exception e) {
			logger.error("An error occurred in getAllDisease", e);
			// You can return an appropriate error page or message if needed.
			return "errorPage";
		} finally {
			logger.trace("Exiting getAllDisease method");
		}
	}

	// Handle POST request to add a new disease
	@PostMapping("/addDisease")
	@ResponseBody
	public String addDisease(@RequestParam String name, String ICDCode, String Description) {
		try {
			logger.trace("Entering addDisease method");

			// Add a new disease and get a message indicating success or failure
			String message = dri.addDisease(name, ICDCode, Description, "Active");

			logger.info("Disease added successfully");

			// Return the result message as a response
			return message;
		} catch (Exception e) {
			logger.error("An error occurred in addDisease", e);
			return "An error occurred while adding the disease.";
		} finally {
			logger.trace("Exiting addDisease method");
		}
	}

	// Handle POST request to edit an existing disease
	@PostMapping("/editDisease")
	@ResponseBody
	public String editDisease(@RequestParam String name, String ICDCode, String Description, String Status,
			Model model) {
		try {
			logger.trace("Entering editDisease method");

			// Edit an existing disease and get a message indicating success or failure
			String message = dri.editDisease(name, ICDCode, Description, Status);

			logger.info("Disease edited successfully");

			// Get all diseases again and add them to the model
			model.addAttribute("diseases", ds.getAllDisease());

			return message;
		} catch (Exception e) {
			logger.error("An error occurred in editDisease", e);
			return "An error occurred while editing the disease.";
		} finally {
			logger.trace("Exiting editDisease method");
		}
	}

	// Handle POST request to delete a disease
	@PostMapping("/deleteDisease")
	@ResponseBody
	public String deleteDisease(@RequestParam String name) {
		try {
			logger.trace("Entering deleteDisease method");

			// Delete a disease and get a message indicating success or failure
			String message = dri.deleteDisease(name);

			logger.info("Disease deleted successfully");

			return message;
		} catch (Exception e) {
			logger.error("An error occurred in deleteDisease", e);
			return "An error occurred while deleting the disease.";
		} finally {
			logger.trace("Exiting deleteDisease method");
		}
	}
}
