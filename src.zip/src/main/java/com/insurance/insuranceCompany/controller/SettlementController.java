package com.insurance.insuranceCompany.controller;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.insurance.insuranceCompany.model.Claim;
import com.insurance.insuranceCompany.model.Claims;
import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.model.Settlements;
import com.insurance.insuranceCompany.repository.NetworkHospitalRepository;
import com.insurance.insuranceCompany.repository.PackagesRepository;
import com.insurance.insuranceCompany.repository.SettlementRepository;
import com.insurance.insuranceCompany.service.HospitalLoginService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/insurance")
public class SettlementController {

	SettlementRepository clr;
	NetworkHospitalRepository nhr;
	PackagesRepository pr;
	HttpSession session;
	HospitalLoginService perrep;
	private final Logger logger;

	@Autowired
	public SettlementController(SettlementRepository clr, NetworkHospitalRepository nhr, PackagesRepository pr,
			HttpSession session, Logger settlementControllerLogger, HospitalLoginService perrep) {
		this.clr = clr;
		this.nhr = nhr;
		this.pr = pr;
		this.session = session;
		this.perrep = perrep;
		this.logger = settlementControllerLogger;
	}

	// for retrieving approved claims
	@GetMapping("/claims")
	public String getApprovedClaims(Model model) {
		logger.trace("Entering getApprovedClaims method");

		try {
			// Check if user is logged in
			Object lc = session.getAttribute("login");
			if (lc == null || (int) lc == 0) {
				model.addAttribute("noaccess", "you need to login first");
				model.addAttribute("login", new Login());
				return "loginPage";
			}

			// Check user access rights
			int access = perrep.checkAccess((int) lc, "/claims");
			if (access == 1) {
				// Retrieve approved claims and processed payments
				List<Claim> claims = clr.getApprovedClaims();
				List<Settlements> stmts = clr.getProcessedPayments();
				model.addAttribute("claims", claims);
				model.addAttribute("settlements", stmts);
				logger.info("Retrieved approved claims and processed payments.");
				return "SettlementsPage";
			}

			model.addAttribute("noaccess", "you don't have access to the settlement section");
			model.addAttribute("hospitalCount", nhr.getHospitalsCount());
			model.addAttribute("packageCount", pr.getPackagesCount());
			logger.warn("User does not have access to the settlement section.");
			return "dashboard";
		} catch (Exception e) {
			logger.error("An error occurred in getApprovedClaims", e);
			model.addAttribute("errorMessage", "An error occurred in processing your request.");
			return "dashboard"; // You can return an appropriate view for error handling
		} finally {
			logger.trace("Exiting getApprovedClaims method");
		}
	}

	// for displaying settlement page for a specific claim
	@GetMapping("/settlement/{claimId}")
	public String getSettlementPage(@PathVariable int claimId, Model model) {
		logger.trace("Entering getSettlementPage method");

		try {
			// Retrieve claim information by claimId
			Claims claim = clr.getClaimById(claimId);

			if (claim == null) {
				logger.warn("Claim not found for claimId: " + claimId);
				return "claimNotFound";
			}

			model.addAttribute("claim", claim);
			logger.info("Retrieved claim for claimId: " + claimId);
			return "Settlements";
		} catch (Exception e) {
			logger.error("An error occurred in getSettlementPage", e);
			model.addAttribute("errorMessage", "An error occurred in processing your request.");
			return "Settlements"; // You can return an appropriate view for error handling
		} finally {
			logger.trace("Exiting getSettlementPage method");
		}
	}

	// for confirming payment processing
	@RequestMapping(value = "/settlement/makePayment", method = RequestMethod.GET)
	public String confirmProcess(@RequestParam Integer claim_id, String transId, Model model) {
		logger.trace("Entering confirmProcess method");

		try {
			// Process payment, add transaction, update payment status
			clr.addTransaction(claim_id, transId);
			clr.updatePayStatus(claim_id);
			clr.addPayment(claim_id);
			logger.info("Payment processed successfully for claim_id: " + claim_id);
			return "redirect:/insurance/claims";
		} catch (Exception e) {
			logger.error("An error occurred in confirmProcess", e);
			model.addAttribute("errorMessage", "An error occurred during payment processing.");
			return "redirect:/insurance/claims";
		} finally {
			logger.trace("Exiting confirmProcess method");
		}
	}
}
