package com.insurance.insuranceCompany.insurancelogconfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.insurance.insuranceCompany.controller.ClaimController;
import com.insurance.insuranceCompany.controller.CustomerController;
import com.insurance.insuranceCompany.controller.DiseaseController;
import com.insurance.insuranceCompany.controller.EmailController;
import com.insurance.insuranceCompany.controller.FileController;
import com.insurance.insuranceCompany.controller.InsurancePackageController;
import com.insurance.insuranceCompany.controller.InsuranceScheduleController;
import com.insurance.insuranceCompany.controller.LoginController;
import com.insurance.insuranceCompany.controller.NetworkHospitalController;
import com.insurance.insuranceCompany.controller.PackagesController;
import com.insurance.insuranceCompany.controller.PaymentController;
import com.insurance.insuranceCompany.controller.SettlementController;

@Configuration
public class LoggingConfig {

	@Bean
	public Logger claimControllerLogger() {
		return LoggerFactory.getLogger(ClaimController.class);
	}

	@Bean
	public Logger customerControllerLogger() {
		return LoggerFactory.getLogger(CustomerController.class);
	}

	@Bean
	public Logger diseaseControllerLogger() {
		return LoggerFactory.getLogger(DiseaseController.class);
	}

	@Bean
	public Logger emailControllerLogger() {
		return LoggerFactory.getLogger(EmailController.class);
	}

	@Bean
	public Logger fileControllerLogger() {
		return LoggerFactory.getLogger(FileController.class);
	}

	@Bean
	public Logger insurancePackageControllerLogger() {
		return LoggerFactory.getLogger(InsurancePackageController.class);
	}

	@Bean
	public Logger insuranceScheduleControllerLogger() {
		return LoggerFactory.getLogger(InsuranceScheduleController.class);
	}

	@Bean
	public Logger loginControllerLogger() {
		return LoggerFactory.getLogger(LoginController.class);
	}

	@Bean
	public Logger networkHospitalControllerLogger() {
		return LoggerFactory.getLogger(NetworkHospitalController.class);
	}

	@Bean
	public Logger packagesControllerLogger() {
		return LoggerFactory.getLogger(PackagesController.class);
	}

	@Bean
	public Logger paymentControllerLogger() {
		return LoggerFactory.getLogger(PaymentController.class);
	}

	@Bean
	public Logger settlementControllerLogger() {
		return LoggerFactory.getLogger(SettlementController.class);
	}
}