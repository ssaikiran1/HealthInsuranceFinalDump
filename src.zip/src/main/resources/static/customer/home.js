$(document).ready(function () {
  $('#last-premium-invoice').on('click', function () {
    const content = $('#last-premium-details').text();

    // Create the PDF document definition
    const pdfDefinition = {
      content: [
        { text: "Premium Payment Invoice", style: "header" },
        { text: content }
      ],
      styles: {
        header: {
          fontSize: 18,
          bold: true,
          margin: [0, 0, 0, 10]
        }
      }
    };

    // Generate and download the PDF
    pdfMake.createPdf(pdfDefinition).download('invoice.pdf');
  });

  $('#pay-premium-now').on('click', function () {
    var amount = parseFloat(1000);

    var options = {
      "key": "rzp_test_ep0Ba9QlOmhL7w",
      "amount": amount * 100, // Amount in paise (100 paise = 1 INR)
      "currency": "INR",
      "handler": function (response) {
        console.log(response.razorpay_payment_id);
      },
    };

    var rzp1 = new Razorpay(options);
    rzp1.open();
  });

  $("#view-premium-schedule").on('click', function () {
    window.location.href = "policyschedule.html";
  });

  $("#view-past-bills").on('click', function () {
    window.location.href = "paymenthistory.html";
  });

  $("#buy-new").on('click', function () {
    window.location.href = "applynew.html";
  });
  
  $("#file-claim").on('click', function () {
    window.location.href = "fileclaim.html";
  });

  $("#view-packages").on('click', function () {
    window.location.href = "insurancepackages.html";
  });
  
  $("#view-claims").on('click', function () {
    window.location.href = "viewflow.html";
  });
 
  var customerId = localStorage.getItem('customerId');
  var tpcUrl = `/customer/policy/${customerId}`;
  var tapcUrl = `/customer/policyActive/${customerId}`;
  var tscUrl = `/customer/policySum/${customerId}`;
  var tmcUrl = `/customer/policyFamActive/${customerId}`;
  var tsacUrl = `/customer/policyActiveSum/${customerId}`;
  var tmacUrl = `/customer/policyFamActive/${customerId}`;
  var thccUrl = `/customer/registeredHospitalsClaims/${customerId}`;
  var ticcUrl = `/customer/individualHospitalsClaims/${customerId}`;
  var policyExpDateUrl = `/customer/policyEXPDate/${customerId}`;
  var policyStartDateUrl = `/customer/policyDates/${customerId}`;
  var premiumAmountUrl = `/customer/policyPremAmount/${customerId}`;	
  var policyUpcomingDateUrl = `/customer/policyUpcomingDate/${customerId}`;  
  var policyLastPaidDateUrl = `/customer/policyLastPaidDate/${customerId}`;
  var tplcidUrl=`/customer/policyId/${customerId}`

  
  $.ajax({
  	url: tplcidUrl,
    success: function (data) {
      $('#policy-id').text(data);
      console.log(data+"idddd");
    },
    error: function (error) {
      console.error('Error fetching data:', error);
    }
  });
    
  
  $.ajax({
  	url: tpcUrl,
    success: function (data) {
      $('#total-policy-count').text(data);
    },
    error: function (error) {
      console.error('Error fetching data:', error);
    }
  });
  
  $.ajax({
  	url: tapcUrl,
    success: function (data) {
      $('#active-policy-count').text(data);
    },
    error: function (error) {
      console.error('Error fetching data:', error);
    }
  });
  
  $.ajax({
  	url: tmcUrl,
    success: function (data) {
      $('#total-member-count').text(data);
    },
    error: function (error) {
      console.error('Error fetching data:', error);
      $('#total-member-count').text(0);
    }
  });
  
  $.ajax({
  	url: tmacUrl,
    success: function (data) {
      $('#active-member-count').text(data);
    },
    error: function (error) {
      console.error('Error fetching data:', error);
    }
  });
  
  $.ajax({
  	url: tscUrl,
    success: function (data) {
      $('#total-covered').text(data);
    },
    error: function (error) {
      console.error('Error fetching data:', error);
    }
  });
  
  $.ajax({
  	url: tsacUrl,
    success: function (data) {
      $('#active-covered').text(data);
    },
    error: function (error) {
      console.error('Error fetching data:', error);
    }
  });
  
  $.ajax({
  	url: thccUrl,
    success: function (data) {
      $('#registered-hospital-claim-count').text(data);
    },
    error: function (error) {
      console.error('Error fetching data:', error);
    }
  });
  
  $.ajax({
  	url: ticcUrl,
    success: function (data) {
      $('#individual-claim-count').text(data);
    },
    error: function (error) {
      console.error('Error fetching data:', error);
      $('#total-member-count').text(0);
    }
  });
  
  // Total Policy Count
$.ajax({
    url: policyExpDateUrl,
    success: function (data) {
        $('#policy-expiry-date').text('Policy Expiry Date: ' + data);
    },
    error: function (error) { 
		$('#policy-expiry-date').text('Policy Expiry Date: ' + "N/A");
        console.error('Error fetching policy expiry date:', error);
    }
});

// Policy Start Date
$.ajax({
    url: policyStartDateUrl,
    success: function (data) {
        $('#policy-start-date').text('Policy Start Date: ' + data);
    },
    error: function (error) {
		 $('#policy-start-date').text('Policy Start Date: ' + "N/A");
        console.error('Error fetching policy start date:', error);
    }
});

// Premium Amount
$.ajax({
    url: premiumAmountUrl,
    success: function (data) {
        $('#preimium-paid').text('Premium Price: ' + data);
        $('#premium-to-pay').text('Premium To Pay: ' + data);
    },
    
    error: function (error) {
		$('#preimium-paid').text('Premium Price: ' + "N/A");
        $('#premium-to-pay').text('Premium To Pay: ' + "N/A");
        console.error('Error fetching premium amount:', error);
    }
});

// Policy Upcoming Date
$.ajax({
    url: policyUpcomingDateUrl,
    success: function (data) {
       $('#policy-next-date').text('Payment Due Date: ' + data);
    },
    error: function (error) {
		$('#policy-next-date').text('Payment Due Date: ' + "N/A");
        console.error('Error fetching policy upcoming date:', error);
    }
});


});
