 document.getElementById('downloadExcelButton').addEventListener('click', function () {
            // Select the table by its id
            const table = document.getElementById('paymentTable');

            // Convert the table data to a worksheet
            const ws = XLSX.utils.table_to_sheet(table);

            // Create a new workbook and add the worksheet
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Payment Data');

            // Generate and download the Excel file
            XLSX.writeFile(wb, 'payment_data.xlsx');
        });